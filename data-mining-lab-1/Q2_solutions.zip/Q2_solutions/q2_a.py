import pandas as pd
import numpy as np
import re
import hashlib
from pathlib import Path


# ============================================================
# PATHS
# ============================================================

BASE = Path(__file__).resolve().parent

NOTICE_DIR = BASE / "notices"
PAIRS_FILE = BASE / "labelled_pairs.csv"


# ============================================================
# LOAD NOTICE FILES
# ============================================================

print("Loading notice files...")

notice_files = sorted(NOTICE_DIR.glob("*.csv"))

print("Notice files found:", len(notice_files))

notice_frames = []

for file in notice_files:
    df = pd.read_csv(file)
    notice_frames.append(df)

notices = pd.concat(notice_frames, ignore_index=True)

print("Total notices:", len(notices))


# ============================================================
# LOAD LABELLED PAIRS
# ============================================================

pairs = pd.read_csv(PAIRS_FILE)

print("Total labelled pairs:", len(pairs))

print("\nLabel counts:")
print(pairs["label"].value_counts())


# ============================================================
# BUILD NOTICE LOOKUP
# ============================================================

notice_lookup = {}

for _, row in notices.iterrows():

    notice_id = row["notice_id"]

    title = "" if pd.isna(row["title"]) else str(row["title"])
    body = "" if pd.isna(row["body"]) else str(row["body"])

    combined_text = title + " " + body

    notice_lookup[notice_id] = combined_text


# ============================================================
# NORMALIZATION
# ============================================================

def normalize_text(text):

    text = text.lower()

    # Neutralize portal-style reference numbers
    text = re.sub(
        r"\b(?:npas|spc|pwd)[-_/:a-z0-9]*\b",
        " refnumber ",
        text
    )

    # Neutralize dates
    text = re.sub(
        r"\b\d{1,2}[-/]\d{1,2}[-/]\d{2,4}\b",
        " date ",
        text
    )

    text = re.sub(
        r"\b\d{4}[-/]\d{1,2}[-/]\d{1,2}\b",
        " date ",
        text
    )

    # Neutralize money expressions
    text = re.sub(
        r"(?:rs\.?|inr)\s*[\d,]+(?:\.\d+)?\s*(?:lakh|crore|cr)?",
        " money ",
        text
    )

    text = re.sub(
        r"\b\d+(?:\.\d+)?\s*(?:lakh|lakhs|crore|crores|cr)\b",
        " money ",
        text
    )

    # Neutralize remaining numbers
    text = re.sub(r"\b\d+(?:\.\d+)?\b", " number ", text)

    # Remove punctuation
    text = re.sub(r"[^a-z0-9\s]", " ", text)

    # Normalize spaces
    text = re.sub(r"\s+", " ", text).strip()

    return text


# ============================================================
# WORD 3-GRAM SHINGLES
# ============================================================

def word_3_shingles(text):

    text = normalize_text(text)

    words = text.split()

    if len(words) < 3:
        return set()

    return {
        " ".join(words[i:i + 3])
        for i in range(len(words) - 2)
    }


# ============================================================
# CHARACTER 5-GRAM SHINGLES
# ============================================================

def char_5_shingles(text):

    text = normalize_text(text)

    if len(text) < 5:
        return set()

    return {
        text[i:i + 5]
        for i in range(len(text) - 4)
    }


# ============================================================
# EXACT JACCARD SIMILARITY
# ============================================================

def jaccard(set_a, set_b):

    if not set_a and not set_b:
        return 1.0

    union = set_a | set_b

    if not union:
        return 0.0

    intersection = set_a & set_b

    return len(intersection) / len(union)


# ============================================================
# Q2(A)(a)
# COMPARE WORD 3-GRAM VS CHARACTER 5-GRAM
# ============================================================

word_results = []
char_results = []

for _, row in pairs.iterrows():

    a = row["notice_id_a"]
    b = row["notice_id_b"]

    text_a = notice_lookup[a]
    text_b = notice_lookup[b]

    # Word 3-grams
    word_a = word_3_shingles(text_a)
    word_b = word_3_shingles(text_b)

    word_score = jaccard(word_a, word_b)

    word_results.append({
        "notice_id_a": a,
        "notice_id_b": b,
        "label": row["label"],
        "word_3gram_jaccard": word_score
    })

    # Character 5-grams
    char_a = char_5_shingles(text_a)
    char_b = char_5_shingles(text_b)

    char_score = jaccard(char_a, char_b)

    char_results.append({
        "notice_id_a": a,
        "notice_id_b": b,
        "label": row["label"],
        "char_5gram_jaccard": char_score
    })


word_results = pd.DataFrame(word_results)
char_results = pd.DataFrame(char_results)


# ============================================================
# PRINT RESULTS
# ============================================================

print("\nPairs measured:", len(pairs))

print("\n===== WORD 3-GRAM JACCARD =====")

print(
    word_results
    .groupby("label")["word_3gram_jaccard"]
    .agg(["count", "mean", "median", "min", "max"])
)


print("\n===== CHARACTER 5-GRAM JACCARD =====")

print(
    char_results
    .groupby("label")["char_5gram_jaccard"]
    .agg(["count", "mean", "median", "min", "max"])
)


# ============================================================
# EXAMPLE SAME PAIR
# ============================================================

same_pair = pairs[pairs["label"] == "same"].iloc[0]

same_a = same_pair["notice_id_a"]
same_b = same_pair["notice_id_b"]

same_text_a = notice_lookup[same_a]
same_text_b = notice_lookup[same_b]

same_word_score = jaccard(
    word_3_shingles(same_text_a),
    word_3_shingles(same_text_b)
)

same_char_score = jaccard(
    char_5_shingles(same_text_a),
    char_5_shingles(same_text_b)
)

print("\n===== EXAMPLE SAME PAIR =====")

print("Notice A:", same_a)
print("Notice B:", same_b)
print("Label:", same_pair["label"])

print(
    "Word 3-gram Jaccard:",
    round(same_word_score, 4)
)

print(
    "Character 5-gram Jaccard:",
    round(same_char_score, 4)
)


# ============================================================
# EXAMPLE DIFFERENT PAIR
# ============================================================

different_pair = pairs[pairs["label"] == "different"].iloc[0]

different_a = different_pair["notice_id_a"]
different_b = different_pair["notice_id_b"]

different_text_a = notice_lookup[different_a]
different_text_b = notice_lookup[different_b]

different_word_score = jaccard(
    word_3_shingles(different_text_a),
    word_3_shingles(different_text_b)
)

different_char_score = jaccard(
    char_5_shingles(different_text_a),
    char_5_shingles(different_text_b)
)

print("\n===== EXAMPLE DIFFERENT PAIR =====")

print("Notice A:", different_a)
print("Notice B:", different_b)
print("Label:", different_pair["label"])

print(
    "Word 3-gram Jaccard:",
    round(different_word_score, 4)
)

print(
    "Character 5-gram Jaccard:",
    round(different_char_score, 4)
)


# ============================================================
# SAVE Q2(A)(a) RESULTS
# ============================================================

q2a_output = BASE / "q2_a_results.csv"

combined_results = word_results.merge(
    char_results,
    on=["notice_id_a", "notice_id_b", "label"]
)

combined_results.to_csv(
    q2a_output,
    index=False
)

print("\nResults saved to:")
print(q2a_output)


# ============================================================
# Q2(A)(b)
# MINHASH
# ============================================================

print("\n======================================")
print("Q2(A)(b) - 256 HASH MINHASH TEST")
print("======================================")


# IMPORTANT:
# The reduced representation size was fixed BEFORE testing.
NUM_HASHES = 256


# ============================================================
# EFFICIENT MINHASH SIGNATURE
# ============================================================

def minhash_signature(shingles):

    """Create a 256-value MinHash signature."""

    if not shingles:
        return [2**64 - 1] * NUM_HASHES

    signature = [2**64 - 1] * NUM_HASHES

    for shingle in shingles:

        shingle_bytes = shingle.encode()

        for i in range(NUM_HASHES):

            value = hashlib.blake2b(
                f"{i}:".encode() + shingle_bytes,
                digest_size=8
            ).digest()

            hash_value = int.from_bytes(
                value,
                "big"
            )

            if hash_value < signature[i]:
                signature[i] = hash_value

    return signature


# ============================================================
# MINHASH SIMILARITY
# ============================================================

def minhash_similarity(signature_a, signature_b):

    if len(signature_a) != len(signature_b):
        raise ValueError("Signatures must have the same length.")

    matches = sum(
        a == b
        for a, b in zip(signature_a, signature_b)
    )

    return matches / len(signature_a)


# ============================================================
# PRECOMPUTE SIGNATURES
# ============================================================

print("\nCreating MinHash signatures for notices...")

signature_lookup = {}

for count, (notice_id, text) in enumerate(
    notice_lookup.items(),
    start=1
):

    shingles = word_3_shingles(text)

    signature_lookup[notice_id] = minhash_signature(
        shingles
    )

    if count % 1000 == 0:
        print(
            "Processed signatures:",
            count,
            "/",
            len(notice_lookup)
        )


print(
    "MinHash signatures created:",
    len(signature_lookup)
)


# ============================================================
# COMPARE EXACT VS MINHASH
# ============================================================

estimation_results = []

for _, row in pairs.iterrows():

    a = row["notice_id_a"]
    b = row["notice_id_b"]

    text_a = notice_lookup[a]
    text_b = notice_lookup[b]

    # Adopted representation: word 3-grams
    shingles_a = word_3_shingles(text_a)
    shingles_b = word_3_shingles(text_b)

    # Exact Jaccard
    exact = jaccard(
        shingles_a,
        shingles_b
    )

    # Reuse precomputed signatures
    signature_a = signature_lookup[a]
    signature_b = signature_lookup[b]

    # Estimated Jaccard
    estimated = minhash_similarity(
        signature_a,
        signature_b
    )

    error = estimated - exact

    absolute_error = abs(error)

    estimation_results.append({
        "notice_id_a": a,
        "notice_id_b": b,
        "label": row["label"],
        "exact_jaccard": exact,
        "minhash_estimate": estimated,
        "error": error,
        "absolute_error": absolute_error
    })


estimation_results = pd.DataFrame(
    estimation_results
)


# ============================================================
# OVERALL ERROR
# ============================================================

print("\nOverall estimation error:")

mae = estimation_results[
    "absolute_error"
].mean()

rmse = np.sqrt(
    np.mean(
        estimation_results["error"] ** 2
    )
)

maximum_error = estimation_results[
    "absolute_error"
].max()

percentile_95 = estimation_results[
    "absolute_error"
].quantile(0.95)


print(
    "Mean absolute error:",
    round(mae, 4)
)

print(
    "RMSE:",
    round(rmse, 4)
)

print(
    "Maximum absolute error:",
    round(maximum_error, 4)
)

print(
    "95th percentile absolute error:",
    round(percentile_95, 4)
)


# ============================================================
# ERROR BY LABEL
# ============================================================

print("\nError by label:")

print(
    estimation_results
    .groupby("label")["absolute_error"]
    .agg([
        "count",
        "mean",
        "median",
        "max"
    ])
)


# ============================================================
# EXAMPLE PAIR
# ============================================================

example = estimation_results.iloc[0]

print("\nExample pair:")

print(
    "Notice A:",
    example["notice_id_a"]
)

print(
    "Notice B:",
    example["notice_id_b"]
)

print(
    "Label:",
    example["label"]
)

print(
    "Exact Jaccard:",
    round(
        example["exact_jaccard"],
        4
    )
)

print(
    "MinHash estimate:",
    round(
        example["minhash_estimate"],
        4
    )
)

print(
    "Absolute error:",
    round(
        example["absolute_error"],
        4
    )
)


# ============================================================
# SAVE MINHASH RESULTS
# ============================================================

minhash_output = BASE / "q2_minhash_results.csv"

estimation_results.to_csv(
    minhash_output,
    index=False
)

print("\nMinHash results saved to:")
print(minhash_output)


print("\n======================================")
print("Q2(A)(b) COMPLETED")
print("======================================")