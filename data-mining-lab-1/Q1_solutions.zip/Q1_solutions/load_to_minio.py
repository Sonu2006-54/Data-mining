from pathlib import Path
import re
import subprocess

SALES_DIR = Path(r"C:\Users\ub02-glab-034\Downloads\data_2\data\sales")
MC_VOLUME = "annapurna_mc_config"
NETWORK = "platform_default"
MC_IMAGE = "quay.io/minio/mc:latest"

pattern = re.compile(
    r"^SALES_(S\d{2})_(\d{4})(\d{2})(\d{2})(?:__R\d+)?\.(csv|parquet)$",
    re.IGNORECASE
)

files = sorted(
    p for p in SALES_DIR.iterdir()
    if p.is_file() and pattern.match(p.name)
)

print(f"Files found: {len(files)}")

for i, file in enumerate(files, 1):
    match = pattern.match(file.name)
    store, year, month, day, extension = match.groups()

    destination = (
        f"local/annapurna/sales/"
        f"store={store}/year={year}/month={month}/"
    )

    command = [
        "docker", "run", "--rm",
        "--network", NETWORK,
        "-v", f"{MC_VOLUME}:/root/.mc",
        "-v", f"{SALES_DIR}:/sales",
        MC_IMAGE,
        "cp",
        f"/sales/{file.name}",
        destination
    ]

    result = subprocess.run(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace"
    )

    if result.returncode != 0:
        print(f"ERROR: {file.name}")
        print(result.stderr)
        raise SystemExit(1)

    if i % 100 == 0 or i == len(files):
        print(f"Loaded {i}/{len(files)}")

print("LOAD COMPLETE")