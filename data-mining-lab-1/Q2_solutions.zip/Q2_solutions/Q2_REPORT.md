# Setubid — near-duplicate detection

**Q2, Section A(a) and A(b).** Every number below is measured on the supplied 12,000-notice corpus and is reproducible from the scripts listed at the end.

---

## A(a) — what "similar" means, mechanically

### The commitment

A notice becomes a **set of word 5-gram shingles**, drawn from the title and body after normalisation. The score between two notices is **Jaccard similarity**:

```
J(A,B) = |A ∩ B| / |A ∪ B|
```

Jaccard is not chosen for familiarity. It is chosen because it is a set-overlap measure — which is the actual question ("do these two notices describe the same work?") — and, decisively, because it is the one similarity here that admits an **unbiased estimator with tunable variance from a fixed-size sketch**. A score I cannot cheaply estimate is unusable at 72 million pairs, so part (b) constrains the choice in part (a). A cosine-over-TF-IDF score would be defensible on separation grounds but drags in corpus-wide IDF weights that shift every night as 4,000 notices arrive — which quietly breaks the stability that section C needs.

### Decision 1 — how finely the text is decomposed

Word n-grams, **k = 5**. The sweep, with normalisation held fixed:

| k | same median J | **worst** different-pair J | recall at zero false merges | false merges at full recall |
|---:|---:|---:|---:|---:|
| 2 | 0.947 | 0.409 | 91.0% | 62.0% |
| 3 | 0.936 | 0.327 | 96.1% | 16.3% |
| 4 | 0.925 | 0.281 | 97.8% | 3.7% |
| **5** | **0.913** | **0.253** | **99.3%** | **1.0%** |
| 6 | 0.902 | 0.232 | 99.6% | 0.2% |
| 8 | 0.880 | 0.204 | 99.6% | 0.2% |

The column that matters is the worst different-pair score, because that is what a false merge looks like. It falls steeply to k=5 and then flattens — k=6 buys 0.02 and k=8 buys nothing more. Shorter grams (k=2,3) let unrelated tenders share too much ordinary procurement English: "the bidder shall", "shall be furnished".

k=5 is the knee. I take k=5 rather than k=6 because longer grams degrade faster on the notices that are already hardest — truncated and terse ones, where there is little text to form grams from at all.

### Decision 2 — what is signal and what is noise

The corpus forced a conclusion here that I did not expect, so I will give the evidence before the answer.

**Boilerplate is the dominant noise, and it is measurable.** Counting lines by how many notices they appear in, and then measuring what share of a body is made of lines appearing in ≥100 notices:

| archetype | n | boilerplate share of body (median) | max | shortest 5% of bodies |
|---|---:|---:|---:|---:|
| `nodal_a` | 2,346 | **48.1%** | 62.9% | 60.6% |
| `nodal_b` | 2,319 | **39.5%** | 55.0% | 50.6% |
| `plain` | 3,827 | 17.4% | 33.6% | 22.8% |
| `terse` | 497 | 16.2% | 20.6% | 16.2% |

The scraping notes said "everything on P001 looks like everything else on P001". That is 48% of the characters, and up to 63%. This is not a stylistic complaint, it is half the representation.

It matters because the labelled negatives are built to exploit it: **361 of the 621 "different" pairs are both from nodal portals**. The test set is deliberately loaded with tenders that share a preamble and share nothing else.

I detect boilerplate by **line document-frequency across the corpus**, not by a hard-coded list of the six portals. 151 lines appear in ≥100 notices; dropping lines above that cutoff is stable across two orders of magnitude of the cutoff:

| df cutoff | % of distinct lines dropped | worst different-pair J | recall at zero false merges |
|---:|---:|---:|---:|
| 20 | 0.156% | 0.256 | 99.3% |
| 50 | 0.084% | 0.250 | 99.3% |
| **100** | **0.079%** | **0.253** | **99.3%** |
| 500 | 0.046% | 0.261 | 98.6% |
| 3000 | 0.006% | 0.458 | 74.9% |

Anything from 20 to 1000 works; only at 3000 does the cutoff stop catching the nodal preambles and performance collapses. I take 100. Learning the cutoff from frequency rather than naming the six portals means a seventh aggregator, or a new preamble on an existing one, is handled without a code change — which the portal notes imply will happen, since those notes were written by three people over two years and already contradict each other.

**The unexpected part.** The obvious next steps — strip reference numbers, strip dates, canonicalise money — mostly do *not* help, and two of them hurt. Ablation at k=5:

| normalisation | same median J | worst different-pair J | recall at zero false merges |
|---|---:|---:|---:|
| none (raw) | 0.605 | 0.445 | 73.1% |
| reference numbers only | 0.615 | 0.447 | 73.5% |
| dates only | 0.631 | 0.445 | 73.8% |
| money canonicalisation only | 0.619 | 0.459 | 73.1% |
| **boilerplate only** | 0.785 | **0.187** | **100.0%** |
| boilerplate + refs + dates | 0.858 | 0.250 | 97.8% |
| boilerplate + refs + dates + money | 0.913 | 0.253 | 99.3% |

Reading the margin (weakest same-pair minus strongest different-pair) directly:

| variant | weakest same | strongest different | **margin** |
|---|---:|---:|---:|
| boilerplate only | 0.197 | 0.187 | **+0.010** |
| boilerplate + refs | 0.205 | 0.250 | **−0.045** |
| boilerplate + dates | 0.200 | 0.187 | +0.012 |
| **boilerplate + money** | **0.214** | **0.188** | **+0.026** |
| boilerplate + refs + dates + money | 0.226 | 0.253 | −0.027 |

**Stripping reference numbers makes the problem worse, not better.** The intuition says they are noise: the same tender carries `MUNI/2025/98454`, `MUNI/2025/38456` and `ref-2025-99944` on three portals. That is true, and it is why same-pair scores rise when you remove them. But they are also *discriminative for negatives* — two unrelated nodal notices differ in their reference strings, and deleting those strings removes evidence of difference. The negatives gain more than the positives do. Dates behave the same way, more weakly.

Money is the opposite: canonicalising `Rs. 4,50,00,000/-`, `Rs. 450.00 lakh` and `INR 4.500 Cr` to one token is the single normalisation that improves the margin, because the estimated value genuinely is shared within a cluster and genuinely does differ between clusters (**0 of 621 labelled different pairs share an estimated value**).

**Adopted:** word 5-gram shingles over title + body, with boilerplate lines (document frequency ≥ 100) removed and monetary amounts canonicalised to a single token per rupee value. **Reference numbers and dates are left in the text exactly as scraped.**

So: boilerplate → deleted. Money → normalised, not deleted. Reference numbers and dates → left alone, against intuition, because the corpus says so.

### The two decisions on one pair each

A **different** pair — two unrelated tenders, both on nodal portals sharing the NPAS preamble:

```
N009445  P001  nodal_a  "Repair and renovation of the government higher secondary school … Chandrapur"   value 163,300,000
N009562  P002  nodal_a  "Desilting and lining of the 2 MLD sewage treatment plant at Chandrapur"        value  35,880,000
```

A **same** pair — a full nodal republication against a truncated corrigendum on another portal:

```
N010018  P004  nodal_b  5,775 chars   "Supply and installation of the check dam on the Sone near Banaskantha"
N010020  P008  terse    1,500 chars   "Corrigendum - Supply and installation of the check dam on the Sone …"
```

| | different pair | same pair |
|---|---:|---:|
| naive: k=3, nothing stripped | **0.531** | **0.222** |
| adopted: k=5, boilerplate stripped, money canonicalised | **0.176** | **0.249** |

Under the naive representation **the ordering is inverted**: two unrelated tenders score 0.531 while two copies of the same tender score 0.222. No threshold anywhere can fix that, because the scores are on the wrong sides of each other. The adopted representation puts them the right way round. The margin is thin — 0.073 — and I would rather state that plainly than dress it up; this is a hard pair, a 1,500-character truncation against a 5,775-character bulletin.

Across the whole labelled set the naive representation achieves 68.1% recall at zero false merges; the adopted one achieves 99.3%.

### Validation beyond the 900 labels

The 900 labelled pairs are a small sample, so I re-ran on ground truth from `clusters.csv`: **all 15,049 true duplicate pairs**, 60,000 random negatives, and 60,000 hard negatives drawn only from nodal portals.

| variant | weakest positive | 1st pct positive | worst random negative | worst hard negative | recall at zero false merges |
|---|---:|---:|---:|---:|---:|
| raw, no normalisation | 0.156 | 0.187 | 0.479 | 0.502 | 68.0% |
| boilerplate only | 0.178 | 0.213 | 0.194 | 0.180 | 99.8% |
| **boilerplate + money (adopted)** | **0.192** | **0.231** | **0.196** | **0.193** | **100.0%** |
| boilerplate + refs + dates + money | 0.203 | 0.246 | 0.267 | 0.206 | 97.9% |

The ablation conclusion holds on 16× more data than the labels provide.

### What the adoption cost

Four things, stated honestly:

1. **A corpus-wide pass to learn boilerplate.** Line document-frequency must be computed over the corpus and refreshed as it grows. It is cheap (seconds) but it is a global dependency — one notice's representation now depends on the rest of the corpus.
2. **A cold-start hole.** A new aggregator's preamble is not stripped until it appears in 100 notices. Until then that portal's notices look like each other, exactly the failure this is meant to prevent. With 4,000 notices a week this window is short, but it is real and must be monitored.
3. **Less text to work with.** Average shingles per notice falls from 735 to 471. On nodal notices roughly half the body is discarded. The weakest positives in the corpus (J ≈ 0.19) are precisely the truncated and terse notices where there was little to spare — deleting boilerplate from a 1,500-character truncation leaves very little.
4. **Not a clean separation.** The adopted representation leaves genuine overlap: weakest true duplicate 0.192, strongest non-duplicate 0.196. No threshold on this score achieves both perfect recall and zero false merges. That is a property of the corpus, not of the choice, and part (b) is where it gets priced.

---

## A(b) — fixing the size of the reduced form

### The reduced form

MinHash. Each notice is stored as **K hash values**; the estimate is the fraction of coordinates on which two signatures agree:

```
Ĵ = (1/K) · #{i : sig_a[i] == sig_b[i]}
```

Each coordinate is an independent Bernoulli(J) trial, so **Ĵ is unbiased with Var(Ĵ) = J(1−J)/K**. That variance is the whole reason for choosing Jaccard in part (a): K is a dial that converts memory into accuracy at a known rate, so the size can be *solved for* rather than guessed.

### The requirement, stated before implementing

The sketch exists to save space, so the standard it must meet is that **it does not materially change the decisions the exact score would make**. Written as a budget over one nightly run across the full 71,994,000-pair space:

- **(i)** expected false merges *introduced by sketching* ≤ **1.0 pair**
- **(ii)** expected extra missed duplicates *introduced by sketching* ≤ **0.5% of 15,049 = 75 pairs**

Budget (i) is **75× tighter than (ii) in absolute pairs.** That ratio is the head of product's asymmetry expressed as a number rather than an adjective, and it is the thing the sketch size is solved against. It is deliberately conservative in one further way: it bounds false merges over *all* pairs, not just the pairs a candidate-generation stage would surface.

Note what these budgets are *not*. They are budgets on the error the **sketch** adds. The exact score already misses some duplicates at any threshold — that floor is a property of the representation, priced in A(a), and no sketch size can improve it.

### Solving for the size

K and the decision threshold t cannot be chosen separately: a higher t sits further from the negative mass and needs fewer hashes. Computing expected errors with exact binomial tails against the measured J distributions (all 15,049 positives; 200,000 negatives scaled to the full pair space):

| t | exact-score misses | exact recall | **smallest K meeting both budgets** | expected false merges | extra misses | bytes/notice |
|---:|---:|---:|---:|---:|---:|---:|
| 0.25 | 318 | 97.9% | > 1536 | — | — | — |
| 0.30 | 698 | 95.4% | 768 | 0.119 | 10.7 | 3,072 |
| **0.35** | **1,197** | **92.0%** | **176** | **0.742** | **−21.4** | **704** |
| 0.40 | 1,598 | 89.4% | 96 | 0.913 | 9.5 | 384 |
| 0.50 | 2,396 | 84.1% | 64 | 0.028 | −65.9 | 256 |
| 0.60 | 3,104 | 79.4% | 48 | 0.000 | −3.8 | 192 |

The frontier is steep on the left. Dropping the threshold from 0.35 to 0.30 buys 3.4 points of recall and costs **4.4× the memory**, because at t=0.30 the gap to the worst negatives (max observed 0.246) is only 0.054 and resolving it needs many more hashes. Going the other way, t=0.50 saves little memory and throws away 8 points of recall.

**Adopted: t = 0.35, K = 192.** K=176 is the smallest size meeting both budgets, but pass/fail is non-monotone in K — the effective threshold is ⌈tK⌉/K, which jumps around as K changes — so the true minimum is fragile. K=192 sits at 0.306 expected false merges, **3.3× inside the binding budget**, costs 768 bytes per notice, and factorises cleanly for the banding a candidate-generation stage will need. That is the reason for 192: it is the budget minimum plus stability headroom, not a round number.

At 768 bytes per notice the whole 12,000-notice corpus sketches to **9.2 MB**. At 4,000 new notices a week the sketch store grows about **160 MB a year** — it stays in memory on one machine for many years, which is what the nightly window requires.

**On pair recall.** 92.0% of duplicate *pairs* sounds lossy, but clusters survive on connectivity, not on every pair. At t=0.35 on the exact score, **2,200 of 2,426 multi-copy clusters (90.7%) remain fully connected**, and the 226 that fragment produce 2,652 components in total — i.e. they mostly split into two. The bidder who sees a road-widening contract nine times today sees it once, or at worst twice.

### Closing the loop: realised error

Sketches built at K=192 over all 12,000 notices in 10.5 s, scored against the 900 labelled pairs:

| | |
|---|---:|
| mean signed error (bias) | **+0.00150** |
| realised RMSE | **0.02306** |
| predicted RMSE, √(J(1−J)/K) | **0.02534** |
| max absolute error | 0.07402 |

Calibration across the range of J:

| true-J band | n | realised sd | predicted sd | ratio |
|---|---:|---:|---:|---:|
| [0.0, 0.1) | 45 | 0.01715 | 0.02096 | 0.82 |
| [0.1, 0.2) | 576 | 0.02211 | 0.02437 | 0.91 |
| [0.2, 0.4) | 36 | 0.02618 | 0.03326 | 0.79 |
| [0.4, 0.6) | 21 | 0.03603 | 0.03586 | 1.00 |
| [0.6, 0.8) | 64 | 0.02895 | 0.03173 | 0.91 |
| [0.8, 1.0) | 158 | 0.02226 | 0.02315 | 0.96 |

The variance tracks J(1−J)/K in shape — largest near J=0.5, shrinking at both ends — which is the argument's main prediction and it holds.

### Where it did not behave as predicted

Two deviations, both real.

**The error does not concentrate the way a naive reading of the formula suggests.** Realised RMSE came in 9% *below* prediction, which looks like good news until you re-run with a different hash seed:

| seed | bias | realised RMSE | predicted RMSE | ratio |
|---:|---:|---:|---:|---:|
| 20240917 | +0.00150 | 0.02306 | 0.02534 | 0.91 |
| 1 | +0.01902 | 0.03082 | 0.02534 | **1.22** |
| 2 | +0.01142 | 0.02556 | 0.02534 | 1.01 |
| 3 | −0.00151 | 0.02337 | 0.02534 | 0.92 |
| 4 | +0.00764 | 0.02385 | 0.02534 | 0.94 |

Mean bias across seeds +0.0076, standard deviation 0.0081 — the same order as the bias itself. The per-pair variance formula is correct, but **every pair in the corpus shares one set of K permutations**, so their errors are correlated. Averaging RMSE over 900 pairs therefore does not concentrate on the theoretical value the way averaging over 900 *independent* draws would. The consequence for operations is not that the expected false-merge count is wrong — it is that **run-to-run variance around it is wider than a Poisson assumption implies**, so "0.3 expected false merges" should not be read as "never more than one".

**A small size-dependent bias.** Splitting the labelled pairs by the size of the smaller shingle set:

| quartile | set size | mean bias |
|---|---|---:|
| Q1 smallest | 166–322 | −0.00581 |
| Q2 | 322–396 | −0.00225 |
| Q3 | 396–489 | +0.00433 |
| Q4 largest | 490–714 | +0.00972 |

The bias trends with set size, which the ideal-permutation model says should not happen. The cause is that the permutations are the 2-independent family `(a·h + b) mod p` rather than truly random ones, for which MinHash is known to be slightly biased. The effect is ≈0.01 at worst against a decision margin of 0.15, so it does not threaten the budget — but it is a real departure, and it would matter if anyone later tried to push t down toward 0.25 where the margin is thin.

### Did the budget hold?

Tested at t=0.35 across five independent seeds, against **120,000 negative pairs — 60,000 random and 60,000 drawn only from nodal portals**, plus all 15,049 true duplicate pairs:

| seed | sketch-induced false merges | sketch recall |
|---:|---:|---:|
| exact score (reference) | 0 / 120,000 | 92.046% |
| 20240917 | **0** | 91.760% |
| 1 | **0** | 92.511% |
| 2 | **0** | 92.225% |
| 3 | **0** | 92.272% |
| 4 | **0** | 92.504% |

Zero false merges in every run, including on the hard nodal negatives specifically constructed to be the failure mode. Recall sits within ±0.5 points of the exact score, well inside budget (ii) — and on three of five seeds the sketch actually caught *more* pairs than the exact score, which is the estimator noise cutting the useful way.

One honest limit: 120,000 negatives is 0.17% of the pair space, so this sample **cannot** resolve a rate of 0.3 false merges per 72 million pairs. Observing zero is consistent with the prediction but does not confirm it to that precision. The binomial model is doing the extrapolation; what the measurement establishes is that nothing contradicts it, and that the dangerous region — hard nodal negatives — behaves as modelled.

---

## Scope

This covers Section A(a) and A(b) as set. The 20-minute nightly ceiling and the bookmark-stability requirement belong to the later sections, but they constrained two choices made here and are worth flagging: Jaccard was chosen over TF-IDF cosine partly because it needs no corpus-wide weights that drift nightly, and K=192 was kept factorisable for the banding that candidate generation will need to avoid the all-pairs comparison that ran for 31 hours.

## Files

```
a_representation.py   A(a): representation, tokenisation variants, separation measurement
b_sketch_size.py      A(b): error-budget solver with exact binomial tails
b_minhash.py          A(b): MinHash sketches + realised-error measurement
```
