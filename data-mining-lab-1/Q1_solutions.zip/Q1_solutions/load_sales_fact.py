from pathlib import Path
import csv
import re
import subprocess
import tempfile
from datetime import datetime

SALES_DIR = Path(r"C:\Users\ub02-glab-034\Downloads\data_2\data\sales")

pattern = re.compile(
    r"^SALES_(S\d{2})_(\d{4})(\d{2})(\d{2})(?:__R\d+)?\.csv$",
    re.IGNORECASE
)

files = sorted(
    p for p in SALES_DIR.iterdir()
    if p.is_file() and pattern.match(p.name)
)

print(f"CSV files found: {len(files)}")


def parse_file(path):
    match = pattern.match(path.name)
    store, year, month, day = match.groups()
    business_date = f"{year}-{month}-{day}"

    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        sample = f.read(4096)
        f.seek(0)

        first_line = sample.splitlines()[0]
        delimiter = ";" if ";" in first_line else ","

        reader = csv.DictReader(f, delimiter=delimiter)

        for row in reader:
            if delimiter == ",":
                bill_no = row["bill_no"]
                line_no = int(row["line_no"])
                product_code = row["product_code"]
                qty = row["qty"]
                unit_price = row["unit_price"]
                line_type = row["line_type"]
                ts_raw = row["ts"]

            else:
                bill_no = row["bill_no"]
                line_no = int(row["line_no"])
                product_code = row["item_code"]
                qty = row["quantity"]
                unit_price = row["rate"]
                line_type = row["type"]
                ts_raw = row["txn_time"]

            # Convert timestamp
            ts = None

            if ts_raw:
                try:
                    if ts_raw.isdigit():
                        ts = datetime.fromtimestamp(
                            int(ts_raw)
                        ).strftime("%Y-%m-%d %H:%M:%S")
                    else:
                        try:
                            ts = datetime.strptime(
                                ts_raw,
                                "%d-%m-%Y %H:%M:%S"
                            ).strftime("%Y-%m-%d %H:%M:%S")
                        except ValueError:
                            ts = datetime.fromisoformat(
                                ts_raw.replace("Z", "+00:00")
                            ).strftime("%Y-%m-%d %H:%M:%S")
                except Exception:
                    ts = None

            yield [
                store,
                bill_no,
                line_no,
                product_code,
                qty,
                unit_price,
                line_type,
                business_date,
                ts
            ]


def sql_quote(value):
    if value is None or value == "":
        return r"\N"

    return str(value).replace("\t", " ").replace("\n", " ").replace("\r", "")


total_rows = 0

with tempfile.NamedTemporaryFile(
    mode="w",
    encoding="utf-8",
    newline="",
    suffix=".tsv",
    delete=False
) as temp:
    temp_path = Path(temp.name)

    for i, path in enumerate(files, 1):

        for row in parse_file(path):

            temp.write(
                "\t".join(sql_quote(value) for value in row)
                + "\n"
            )

            total_rows += 1

        if i % 100 == 0 or i == len(files):
            print(f"Prepared {i}/{len(files)} files")


print(f"Rows prepared: {total_rows}")

copy_sql = """
CREATE TEMP TABLE sales_stage (
    store_id VARCHAR(3),
    bill_no VARCHAR(100),
    line_no INTEGER,
    product_code VARCHAR(50),
    qty NUMERIC,
    unit_price NUMERIC,
    line_type VARCHAR(20),
    business_date DATE,
    ts TIMESTAMP
);

COPY sales_stage
FROM STDIN
WITH (
    FORMAT text,
    DELIMITER E'\\t',
    NULL '\\N'
);

INSERT INTO sales_fact (
    store_id,
    bill_no,
    line_no,
    product_code,
    qty,
    unit_price,
    line_type,
    business_date,
    ts
)
SELECT
    store_id,
    bill_no,
    line_no,
    product_code,
    qty,
    unit_price,
    line_type,
    business_date,
    ts
FROM sales_stage
ON CONFLICT (store_id, bill_no, line_no)
DO NOTHING;
"""

# Run PostgreSQL COPY using psql
command = [
    "docker",
    "exec",
    "-i",
    "annapurna-postgres",
    "psql",
    "-U",
    "postgres",
    "-d",
    "annapurna",
    "-v",
    "ON_ERROR_STOP=1",
    "-c",
    copy_sql
]

with open(temp_path, "r", encoding="utf-8") as f:

    result = subprocess.run(
        command,
        stdin=f,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace"
    )

if result.returncode != 0:
    print("LOAD FAILED")
    print(result.stderr)
    raise SystemExit(1)

print(result.stdout)

temp_path.unlink(missing_ok=True)

print("IDEMPOTENT LOAD COMPLETE")